<script>
    $(document).ready(function () {
        var sel = $('#country');
        var selected = sel.val();
        alert(selected);// cache selected value, before reordering
        var opts_list = sel.find('option');
        opts_list.sort(function(a, b) { return $(a).text() > $(b).text() ? 1 : -1; });
        sel.html('').append(opts_list);
        sel.val(selected);
    });
</script>