<script>
$(document).ready(function () {
    $('#checkbox3').on('click',function (e) {
        e.preventDefault();
        $('#pets-green').addClass('add-green-color');
        $('#pets-red').removeClass('add-radio-color');
        $('#pets').val('yes');
    });
    $('#checkbox4').on('click',function (e) {
        e.preventDefault();
        $('#pets-red').addClass('add-radio-color');
        $('#pets-green').removeClass('add-green-color');
        $('#pets').val('no');
    });
    $('#checkbox5').on('click',function (e) {
        e.preventDefault();
        $('#music-red').addClass('add-radio-color');
        $('#music-green').removeClass('add-green-color');
        $('#music').val('no');
    });
    $('#checkbox6').on('click',function (e) {
        e.preventDefault();
        $('#music-green').addClass('add-green-color');
        $('#music-red').removeClass('add-radio-color');
        $('#music').val('yes');
    });

    $('#checkbox7').on('click',function (e) {
        e.preventDefault();
        $('#smoking-red').addClass('add-radio-color');
        $('#smoking-green').removeClass('add-green-color');
        $('#smoking').val('no');
    });
    $('#checkbox8').on('click',function (e) {
        e.preventDefault();
        $('#smoking-green').addClass('add-green-color');
        $('#smoking-red').removeClass('add-radio-color');
        $('#smoking').val('yes');
    });

    $('#checkbox9').on('click',function (e) {
        e.preventDefault();
        $('#back-red').addClass('add-radio-color');
        $('#back-green').removeClass('add-green-color');
        $('#back').val('no');
    });
    $('#checkbox10').on('click',function (e) {
        e.preventDefault();
        $('#back-green').addClass('add-green-color');
        $('#back-red').removeClass('add-radio-color');
        $('#back').val('yes');
    });
});
</script>