<?php $__env->startSection('content'); ?>

    <!-- get join with us -->

    <div class="get-join-with-us">
        <div class="container">
            <div class="row">
                <div class="join-section-title">
                    <h2>Join</h2>
                    <h3>Us Today!</h3>
                </div>
                <div class="col-sm-12 get-join-as">
                    <h3 class="get-join-tag">Join as</h3>
                    <div class="col-sm-5">
                        <a href="<?php echo e(url('/sign-up/driver')); ?>">Ridemates (Driver)</a>
                    </div>
                    <div class="col-sm-2">
                        <span class="cd-ortext">Or</span>
                    </div>
                    <div class="col-sm-5">
                        <a href="<?php echo e(url('/sign-up/customer')); ?>" class="riders">Riders (Passenger)</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>