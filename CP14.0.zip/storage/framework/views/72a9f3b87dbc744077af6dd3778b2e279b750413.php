<?php $__env->startSection('content'); ?>
    <!-- about us area -->
    <div class="get-offer-ride">
        <div class="container">
            <p class="row">
                <p class="col-sm-12">
                    <h3 class="get-about-section-header section-about-us-top">How It Works</h3>
                    <p class="about-us-details">
                        <p>This is a people powered community built on trust, with user friendly platform suitable for anyone, anytime, anywhere. All you need to do is to enjoy the ride. Welcome to getWOBO.</p>
                        <h4 style="text-align: center">Wanna get somewhere? NEED A RIDE? (for RIDERS)</h4>
                        <p><b><u><i>Step 1:</i></u> Find a ride</b><p>
                        <p>Just say where you’re heading, where you’re leaving from and when. Then pick a ride that works for you! If you need more detail, you can message your Ridemate before booking. You may also want to check out Ridemate' profiles. You’ll see what others say about their ride with them.</p>
                        <p><b><u><i>Step 2:</i></u> Book and pay online</b></p>
                        <p>Tap book and pay for your seat. Once you do, you’ll have the Ridemate’s phone number to get in touch. If a Ridemate cancels, we’ll refund you according to our cancellation policy.</p>
                        <p><b><u><i>Step 3:</i></u> Riding together</b></p>
                        <p>Enjoy the ride and don’t forget to leave a rating!</p><br/>
                        <h4 style="text-align: center">Have empty seats? OFFERING A RIDE? (for RIDEMATES)</h4><br/>
                        <p><b><u><i>Step 1:</i></u> Offer a ride</b></p>
                        <p>Just say where you’re going, where you would like to pick up and drop off truest Riders, and when. Share your ride cost, it is just that easy for everyone!</p>
                        <p><b><u><i>Step 2:</i></u> Your Riders book a seat and pay online</b></p>
                        <p>When a Rider books a seat with you, we’ll share their phone number in case you need to get in touch. You can check out the details of the Riders anytime.</p>
                        <p><b><u><i>Step 3:</i></u> Ride together</b></p>
                        <p>Share stories, funs or just a quiet ride with other Riders.</p><br/>
                        <h4 style="text-align: center"><b>Both Riders and Ridemates are visible to each other through this platform. This is how thing works</b></h4><br/>
                        <p><i>Choose who you ride with:</i> You may see each other’s profile, ride details such as dates and point for pick-up & drop-off entirely at your convenient.</p>
                        <p><i>Check out their ratings:</i> See what others say about them, and benefit from the experience of other members when choosing who to ride with.</p>
                        <p><i>Find out more about them:</i> Check out their preferences and mini bio so you know all about who you’ll be travelling with.</p>
                        <p><i>Profiles are moderated:</i> All profiles, photos, ratings, rides and ride comments are moderated to maintain trust and respect in the community.</p>
                        <p><i>Get in touch before you travel:</i> Use our secure messaging system. Get to know each other before the ride and easily organise where to meet.</p><br/><br/><br/>
                        <h4 style="text-align:center;"><b>Ratings</b></h4><br/><br/>
                        <p>getWOBO’s rating system are merely visible recommendations as to foster decision making process prior to confirm any ride. This is important, the process helps to elevate trust within the community. So, please do not forget to rate to share your experience with the rest of the community after your ride.</p>
                        <p><i>How do I leave a rating?</i></p>
                        <p>You can leave a rating the day after you travel at your convenience. getWOBO rating system is applicable both for Riders and Ridemates.</p>
                        <p>Ratings done will be posted on each profile, applicable to both Riders and Ridemates and visible to the rest of the community. Follow these steps the next time you leave a rating:</p>
                        <p>1. Choose the adjective that best describes your ride experience.<p>
                        <p><b>How Was Your Experience</b></p><br/>
                                <p>1. Outstanding</p>
                                <p>2. Excellent</p>
                                <p>3. Good</p>
                                <p>4. Poor</p>
                                <p>5. Very Disappointing</p>
                            <br/>
                    <p>Think of whether you would recommend this person to your friends or family:</p>

                        <p>1. Outstanding - An overall positive experience, can’t complain.</p>
                        <p>2. Excellent - they were reliable, you felt comfortable and you had a very pleasant experience.</p>
                        <p>3. Good - they were on time and it was an overall positive experience.</p>
                        <p>4. Poor - Not a great experience. Wouldn’t recommend to others.</p>
                        <p>5. Very Disappointing - To avoid. Never again.</p>
                    <br/>
</div>
                </div>
                <div class="col-xs-12 col-lg-12">
                    <div class="getwobo-pagination">
                        <nav aria-label="Page navigation">
                            <ul class="pagination">
                                <?php if(isset($_GET['page'])){$page = $_GET['page'];}?>
                                <li>
                                    <a href="<?php if(isset($page)){if($page > 1){echo '?page='.($page - 1);}else{echo '?page=1';}}?>" aria-label="Previous">
                                        <span aria-hidden="true">&laquo;</span>
                                    </a>
                                </li>
                                <?php for($i = 1;$i < 5;$i++): ?>
                                    <li class="<?php if(isset($page)){if($page == $i){echo 'active';}}?>"><a href="<?php echo '?page='.$i ?>"><?php echo $i;?></a></li>
                                <?php endfor; ?>
                                <li>
                                    <a href="<?php if(isset($page)){if($page > 1 && $page < 4){echo '?page='.($page + 1);}}?>" aria-label="Next">
                                        <span aria-hidden="true">&raquo;</span>
                                    </a>
                                </li>
                            </ul>
                        </nav>
                    </div>
                </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>