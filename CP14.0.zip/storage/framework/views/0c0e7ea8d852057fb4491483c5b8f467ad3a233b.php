<?php $__env->startSection('content'); ?>

    <?php if(Auth::check() && Auth::user()->role == 'driver'): ?>
        <div class="get-offer-ride">
            <div class="container">
                <div class="row">
                    <?php if(session()->has('error')): ?>
                        <p class="alert alert-danger">
                            <?php echo e(session()->get('error')); ?>

                        </p>
                    <?php endif; ?>
                    <div class="ridemate-offer-button">
                        <button class="btn btn-info btn-offer"><a style="color: #ffffff;" href="<?php echo e(url('/d/offer-ride')); ?>">Offer a ride <i class="fas fa-car"></i></a></button>
                        <button class="btn btn-info btn-offer">Requests For Ride</button>
                    </div>
                    <!-- Ride details -->
                    <div class="get-ridemate-single">
                        <h3 class="check-total-fare text-center">Requests of Rides</h3>

                    <?php if(isset($reqs)): ?>
                        <?php $__currentLoopData = $reqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $req): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(!isset($req->exx)): ?>

                                <!-- single request area -->

                                    <div class="col-sm-12 col-md-10 col-md-offset-1 col-lg-8  col-lg-offset-2 col-xs-12 ridemate-details-offer padding-left-o">
                                        <h4 class="ridemate-home-h3">Ride Details</h4>
                                        <div class="col-sm-8 col-xs-12 padding-left-o">
                                            <div class="get-car-details-area clearfix">
                                                <div class="col-sm-5">
                                                    <span class="ride-label">Form<span class="right-into">:</span></span>
                                                </div>
                                                <div class="col-sm-6">
                                                    <span class="ride-label-badge"><?php echo e($req->from); ?></span>
                                                </div>
                                            </div>
                                            <div class="get-car-details-area clearfix">
                                                <div class="col-sm-5">
                                                    <span class="ride-label">To<span class="right-into">:</span></span>
                                                </div>
                                                <div class="col-sm-6">
                                                    <span class="ride-label-badge"><?php echo e($req->to); ?></span>
                                                </div>
                                            </div>
                                            <div class="get-car-details-area clearfix">
                                                <div class="col-sm-5">
                                                    <span class="ride-label">Requested Seats <span class="right-into">:</span></span>
                                                </div>
                                                <div class="col-sm-6">
                                                    <span class="ride-label-badge"><?php echo e($req->required_seat); ?></span>
                                                </div>
                                            </div>
                                            <button class="btn btn-info btn-offer ride-final-ride-button" type="button" data-toggle="modal" data-target="#myModalx<?php echo e($req->id); ?>">Riders Details</button>
                                        </div>
                                        <div class="col-sm-4 col-xs-12 ride-details-feature">
                                            <div class="get-car-details-area clearfix">
                                                <div class="col-sm-5">
                                                    <span class="ride-label">Date <span class="right-into">:</span></span>
                                                </div>
                                                <div class="col-sm-6">
                                                    <span class="ride-label-badge"><?php echo e(date('Y-m-d H:i A', strtotime($req->departure_date))); ?></span>
                                                </div>
                                            </div>
                                            <button class="btn btn-info btn-offer offer-ride-ridemate-home"><a style="color: purple;" href="<?php echo e(url('/d/offer-ride?req='.$req->id)); ?>">Offer Ride</a></button>
                                        </div>
                                    </div>
                                    <!-- end single ridemate area -->

                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                    <!-- end ridemate details -->
                </div>
            </div>
        </div>
    <?php else: ?>

        <!-- where to ara -->
        <div class="get-where">
            <div class="container">
                <div class="row">
                    <h2 class="get-section-header">Where to?</h2>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor inc ididunt ut labore et dolore magna aliqua.</p>
                    <div class="col-sm-12 clearfix">
                        <?php echo $__env->make('frontend.includes.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <?php if(isset($errors)): ?>
                            <?php $__currentLoopData = $errors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <p class="alert alert-danger">
                                    <?php echo e($error); ?>

                                </p>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                    <div class="get-a-ride">
                        <form action="<?php echo e(url('/search')); ?>" method="post">
                            <?php echo e(csrf_field()); ?>

                            <div class="col-sm-3 col-xs-12 padding-left-o">
                                <input type="text" name="from" id="" data-live-search="true" class="get-select-picker placepicker form-control" placeholder="From" required>
                            </div>
                            <div class="col-sm-3 col-xs-12 padding-left-o">
                                <input type="text" name="to" id="" data-live-search="true" class="get-select-picker placepicker form-control" placeholder="To" required>
                            </div>
                            <div class="col-sm-2 col-xs-12 padding-left-o">
                                <input type="text" name="when" class="form-control" id="datetimepicker5" placeholder="When" required>
                            </div>
                            <div class="col-sm-2 col-xs-12 padding-left-o">
                                <select name="seats" class="get-select-picker" title="Seats" required>
                                    <option value="1">1 seats</option>
                                    <option value="2">2 seats</option>
                                    <option value="3">3 seats</option>
                                    <option value="4">4 seats</option>
                                    <option value="5">5 seats</option>
                                </select>
                            </div>
                            <div class="col-sm-2 col-xs-12 padding-left-o">
                                <button type="submit" class="btn btn-info btn-offer"><span>Get a ride </span><i class="fas fa-car"></i></button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!-- end where to -->

        <!-- landing area -->
        <div class="get-landing-area clearfix">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12">
                        <div class="get-landing-text">
                            <h2 class="get-bold-text">Are you driving <br> somewhere soon?</h2>
                            <p>Take a ride through GetWobo and change the experience of the journey that you never feel before.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- end landing area -->



        <!-- todays departure -->
        <div class="get-departure clearfix">
            <div class="container">
                <div class="row">
                    <h2 class="get-departure-title">Today's Departure</h2>
                <?php if($offers->isNotEmpty()): ?>
                    <?php $__currentLoopData = $offers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $of): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $books = 0 ?>
                        <?php if($of->bookings->isNotEmpty()): ?>
                            <?php $__currentLoopData = $of->bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $books += $book->seat_booked ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        <!-- single departure -->
                            <div class="col-sm-6 col-xs-12 padding-left-o">
                                <div class="get-single-departure clearfix">
                                    <div class="col-md-8 col-sm-12">
                                        <div class="get-user-icon">
                                            <img src="<?php echo e(asset('public/assets/frontend/img/user/user-1.jpg')); ?>" alt="">
                                        </div>
                                        <div class="get-user-details">
                                            <h3 class="get-user-name"><span>Name <span class="get-right-icon">:</span></span>
                                                <span class="get-dynamic-name"><?php echo e($of->user_details->name); ?> <?php echo e($of->user_data->last_name); ?></span></h3>
                                            <h3 class="get-user-name"><span>Age <span class="get-right-icon">:</span></span>
                                                <span class="get-dynamic-name">26</span></h3>
                                            <h3 class="get-user-name"><span>Seats Available <span class="get-right-icon">:</span></span>
                                                <span class="get-dynamic-name"></span></h3>
                                            <ul class="get-user-icon-layer">
                                                <?php for($i = 0; $i < ($of->total_seats - $books); $i++): ?>
                                                    <li><i class="fas fa-user"></i></li>
                                                <?php endfor; ?>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="col-md-4 col-sm-12">
                                        <div class="get-user-ratings">
                                            <ul class="get-rate-user">
                                                <li><i class="fas fa-star"></i></li>
                                                <li><i class="fas fa-star"></i></li>
                                                <li><i class="fas fa-star"></i></li>
                                                <li><i class="fas fa-star"></i></li>
                                                <li><i class="fas fa-star"></i></li>
                                            </ul>
                                            <a href="<?php if(Auth::check() && Auth::user()->role == 'driver'): ?> <?php echo e(url('/d/ride-details/'.$of->link)); ?> <?php elseif(Auth::check() && Auth::user()->role == 'customer'): ?> <?php echo e(url('/c/ride-details/'.$of->link)); ?> <?php else: ?> <?php echo e(url('/ride-details/'.$of->link)); ?> <?php endif; ?>"><button class="btn btn-info btn-offer text-uppercase">Book Ride</button></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- end signle departure -->
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <h3>There's no departure in your area today.</h3>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <!-- end todays deparature -->

        <!-- about us -->
        <div class="get-about-us clearfix">
            <div class="container">
                <div class="row">
                    <h2 class="get-about-us-title">Go Literally <span>anywhere.</span> <br> from <span>everywhere.</span></h2>
                    <div class="col-sm-3 padding-left-o">
                        <div class="get-single-text clearfix">
                            <div class="icon"><img class="icon-1" src="<?php echo e(asset('public/assets/frontend/img/icon-1.png')); ?>" alt="icon-1"></div>
                            <h3 class="get-single-title">Smart</h3>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim.</p>
                        </div>
                    </div>
                    <div class="col-sm-3 col-sm-offset-1">
                        <div class="get-single-text clearfix">
                            <div class="icon"><img class="icon-2" src="<?php echo e(asset('public/assets/frontend/img/icon-2.png')); ?>" alt="icon-2"></div>
                            <h3 class="get-single-title">Simple</h3>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud.</p>
                        </div>
                    </div>
                    <div class="col-sm-4 col-sm-offset-1">
                        <div class="get-single-text clearfix">
                            <div class="icon"><img class="icon-3" src="<?php echo e(asset('public/assets/frontend/img/icon-3.png')); ?>" alt="icon-3"></div>
                            <h3 class="get-single-title">Seamless</h3>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- end about us -->
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>