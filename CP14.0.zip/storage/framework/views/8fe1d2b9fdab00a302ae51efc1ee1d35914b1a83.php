<?php $__env->startSection('content'); ?>
    <h1 style="text-align: center;line-height: 680%;color: #3d055c;">This Page Is Currently Under Construction.</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>