<?php $__env->startSection('content'); ?>

    <div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">


        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Create Driver</h1>
            </div>
        </div><!--/.row-->

        <div class="row">
            <div class="col-lg-12">
                <?php echo $__env->make('admin.includes.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php if($errors->any()): ?>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p class="alert alert-danger">
                            <?php echo e($error); ?>

                        </p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
        </div>

        <div class="row">
            <div class="col-xs-12 col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <div class="panel-body">
                        <form method="post" action="<?php echo e(url('/admin/create-driver')); ?>" role="form">
                            <fieldset>
                                <?php echo e(csrf_field()); ?>

                                <div class="form-group">
                                    <input class="form-control" placeholder="Enter User Name" name="name" type="text" required="" value="<?php echo e(old('name')); ?>">
                                </div>
                                <div class="form-group">
                                    <input class="form-control" placeholder="Enter Last Name" name="last_name" value="<?php echo e(old('last_name')); ?>">
                                </div>
                                <div class="form-group">
                                    <input class="form-control" placeholder="Enter Your Email" name="email" type="email" autofocus="" required="" value="<?php echo e(old('email')); ?>">
                                </div>
                                <div class="form-group">
                                    <input class="form-control" placeholder="Password" name="password" type="password" value="" required="">
                                </div>
                                <div class="form-group">
                                    <input class="form-control" placeholder="Re-type Password" name="repass" type="password" value="" required="">
                                </div>
                                <div class="form-group">
                                    <input type="datetime" class="form-control datepicker-f" placeholder="MM/YY" name="dob" value="<?php echo e(old('dob')); ?>">
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control" placeholder="Enter Address" name="address" value="<?php echo e(old('address')); ?>">
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control" placeholder="Enter Id Card No" name="id_card" value="<?php echo e(old('id_card')); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="gender">Gender</label>
                                    <select name="gender" class="get-select-picker" title="Gender">
                                        <option value="male" <?php if(old('gender') == 'male'): ?><?php echo e('selected'); ?><?php endif; ?>>Male</option>
                                        <option value="female" <?php if(old('gender') == 'female'): ?><?php echo e('selected'); ?><?php endif; ?>>Female</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="upload-driving-licence">Upload Picture</label>
                                    <div class="file">
                                        <input type="file" class="" name="picture">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control" placeholder="Enter Car's Registration No" name="car_reg" value="<?php echo e(old('car_reg')); ?>">
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control" placeholder="Enter Driving License No" name="driving_license" value="<?php echo e(old('driving_license')); ?>">
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control" placeholder="Enter Expiration Date" name="expiry" value="<?php echo e(old('expiry')); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="upload-driving-licence">Upload Driving License</label>
                                    <div class="file">
                                        <input type="file" class="" name="uploads">
                                    </div>
                                </div>
                                <button class="btn btn-info btn-offer" type="submit">Create</button>
                            </fieldset>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-sm-12">
            <p class="back-link">© 2018. All rights reserved</p>
        </div>
    </div>	<!--/.main-->

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>