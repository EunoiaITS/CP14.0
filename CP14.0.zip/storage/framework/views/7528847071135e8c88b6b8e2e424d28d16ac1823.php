<?php if(session()->has('success')): ?>
    <p class="alert alert-success alert-dismissable"><?php echo e(session()->get('success')); ?></p>
<?php endif; ?>

<?php if(session()->has('error')): ?>
    <p class="alert alert-danger "><?php echo e(session()->get('error')); ?></p>
<?php endif; ?>