<?php $i = 0; ?>
<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php $i++; ?>
<!-- Modal -->
<div class="modal fade" id="myModalps<?php echo e($i); ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="myModalLabel">Edit User</h4>
            </div>
            <div class="modal-body">
                <form id="edit<?php echo e($i); ?>" method="post" action="<?php echo e(url('/admin/list')); ?>" role="form">
                    <?php echo e(csrf_field()); ?>

                    <fieldset>
                        <div class="form-group">
                            <input class="form-control" placeholder="Edit User Name" name="name" type="text" autofocus="" value="<?php echo e($user->name); ?>">
                        </div>
                        <div class="form-group">
                            <input class="form-control" placeholder="New Password" name="password" type="password" value="">
                        </div>
                        <div class="form-group">
                            <input class="form-control" placeholder="Re-type New Password" name="repass" type="password" value="">
                        </div>
                    </fieldset>
                    <input type="hidden" name="user_id" value="<?php echo e($user->id); ?>">
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModalpr<?php echo e($i); ?>">Save</button>
                <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
            </div>
        </div>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="myModalpr<?php echo e($i); ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="myModalLabel">Confirmation</h4>
            </div>
            <div class="modal-body">
                <p>Are you sure you want to Proceed ?</p>
            </div>
            <div class="modal-footer">
                <button type="submit" form="edit<?php echo e($i); ?>" class="btn btn-primary">Yes</button>
                <button type="button" class="btn btn-default" data-dismiss="modal">No</button>
            </div>
        </div>
    </div>
</div>

    <!-- Modal -->
    <div class="modal fade" id="myModalD<?php echo e($i); ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title" id="myModalLabel">Confirmation</h4>
                </div>
                <div class="modal-body">
                    <p>Are you sure you want to <strong>delete</strong> ?</p>
                </div>
                <div class="modal-footer">
                    <form method="post" action="<?php echo e(url('/admin/user/delete/'.$user->id)); ?>">
                        <?php echo e(csrf_field()); ?>

                        <button type="submit" class="btn btn-primary">Yes</button>
                        <button type="button" class="btn btn-default" data-dismiss="modal">No</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>