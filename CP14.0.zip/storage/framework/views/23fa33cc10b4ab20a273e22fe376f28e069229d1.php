<?php $__env->startSection('content'); ?>
    <?php $total_books = 0 ?>
    <?php $__currentLoopData = $data->bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $books): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $total_books += $books->seat_booked; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div class="get-offer-ride">
        <div class="container">
            <div class="row">
                <h3 class="get-popular-list list-option-ride">Ride Details</h3>
                <div class="col-sm-12 clearfix">
                    <?php echo $__env->make('frontend.includes.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php if(isset($errors)): ?>
                        <?php $__currentLoopData = $errors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <p class="alert alert-danger">
                                <?php echo e($error); ?>

                            </p>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>

                <?php if(Auth::check() && Auth::user()->role == 'driver' && Auth::id() == $data->offer_by): ?>
                    <?php if(empty($ride_start)): ?>
                    <?php if(date('Y-m-d H:i') >= date('Y-m-d H:i', strtotime($data->departure_time)) && date('Y-m-d H:i') <= date('Y-m-d H:i', strtotime($data->departure_time)+3600)): ?>
                <div class="get-form-control-button">
                    <button type="button" class="btn btn-info btn-offer" data-toggle="modal" data-target="#startRidePop">Start the Ride</button>
                </div>
                        <?php endif; ?>
                        <?php else: ?>
                        <?php if(!isset($ride_start->end_time)): ?>
                        <div class="get-form-control-button">
                            <p class="alert alert-success">Your ride was started. Please click to end the ride.</p>
                            <button type="button" class="btn btn-info btn-offer" data-toggle="modal" data-target="#endRidePop">End the Ride</button>
                        </div>
                            <?php endif; ?>
                        <?php endif; ?>
                <?php endif; ?>
                <div class="col-sm-12 get-join-as">
                    <div class="col-sm-5">
                        <div class="form-ride-details">
                            <h3>Form</h3>
                            <h2 id="start"><?php echo e($data->origin); ?></h2>
                            <p></p>
                            <p class="get-departure-time">Departure Time: <span class="get-time"><?php echo e(date('Y-m-d H:i A', strtotime($data->departure_time))); ?></span></p>
                        </div>
                    </div>
                    <div class="col-sm-2">
                        <div class="arrow-icon">
                            <img src="<?php echo e(asset('public/assets/frontend/img/arrow-icon.png')); ?>" alt="">
                        </div>
                    </div>
                    <div class="col-sm-5">
                        <div class="form-ride-details">
                            <h3>To</h3>
                            <h2 id="end"><?php echo e($data->destination); ?></h2>
                            <p></p>
                            <p class="get-departure-time">Arraival Time: <span class="get-time"><?php echo e(date('Y-m-d H:i A', strtotime($data->arrival_time))); ?></span></p>
                        </div>
                    </div>
                </div>
                <!--End rdemade details  -->
                <!-- available seats -->
                <div class="get-available-seats get-normal-seats clearfix">
                    <div class="col-sm-4 padding-left-o">
                        <h3 class="check-total-fare">Available Seats</h3>
                    </div>
                    <div class="col-sm-5 col-sm-offset-3 col-xs-12">
                        <h3 class="price-per-seats">Price Per Seat: <span>$<?php echo e($data->price_per_seat); ?></span></h3>
                    </div>
                    <ul class="get-ride-seat clearfix">
                        <li>
                            <div class="ride-seat-icon">
                                <i class="fas fa-user-times fixed-hover"></i>
                                <span>Ridermate</span>
                            </div>
                        </li>
                        <?php $total = 1; ?>
                            <?php if(isset($data->bookings)): ?>
                                <?php $__currentLoopData = $data->bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($book->status == 'booked'): ?>
                                    <?php for($j = 1; $j <= $book->seat_booked; $j++): ?>
                                        <li>
                                            <div class="ride-seat-icon first-ride">
                                                <i class="fas fa-user fixed-hover" data-toggle="modal" data-target="#myModalnsx<?php echo e($book->id); ?>"></i>
                                                <span>Booked</span>
                                            </div>
                                        </li>
                                        <?php $total++; ?>
                                    <?php endfor; ?>
                                    <?php elseif($book->status == 'confirmed'): ?>
                                    <?php for($k = 1; $k <= $book->seat_booked; $k++): ?>
                                        <li>
                                            <div class="ride-seat-icon first-ride">
                                                <i class="fas fa-user fixed-hover" data-toggle="modal" data-target="#myModalnsx<?php echo e($book->id); ?>"></i>
                                                <span>Confirmed</span>
                                            </div>
                                        </li>
                                        <?php $total++; ?>
                                    <?php endfor; ?>
                                    <?php else: ?>
                                        <?php echo e(''); ?>

                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        <?php for($i = $total; $i <= $data->total_seats; $i++): ?>
                            <li>
                                <div class="ride-seat-icon first-ride">
                                    <i class="fas fa-user"></i>
                                    <span>Empty</span>
                                </div>
                            </li>
                        <?php endfor; ?>
                    </ul>
                    <?php if(Auth::check() && Auth::user()->role != 'driver'): ?>
                    <span class="text-right">*Click To Select Your Seat</span>
                    <?php endif; ?>
                    <div class="col-sm-4 padding-left-o">
                        <h3 class="price-per-seats get-total-fare">Total Fare: <span>$<?php echo e($data->price_per_seat*$total_books); ?></span></h3>
                    </div>
                    <?php if(Auth::check()): ?>
                        <?php if(Auth::user()->role == 'customer'): ?>
                            <?php if($total_books != $data->total_seats && $data->status == 'active'): ?>
                                <div class="col-sm-5 col-sm-offset-3 col-xs-12">
                                    <button class="btn btn-info btn-offer" data-toggle="modal" data-target="#book-ride">Request To Book</button>
                                </div>
                                <?php endif; ?>
                        <?php endif; ?>
                    <?php else: ?>
                        <div class="col-sm-5 col-sm-offset-3 col-xs-12">
                            <button class="btn btn-info btn-offer" data-toggle="modal" data-target="#myModal2">Request To Book</button>
                        </div>
                    <?php endif; ?>
                </div>
                <!-- end available seats -->

                <!-- get direction -->
                <div class="get-check-direction clearfix">
                    <h3 class="check-direction-title">Check Direction</h3>
                    <div id="googleMap"></div>
                </div>
                <!-- end get direction -->

                <!-- car details -->
                <div class="get-available-seats">
                    <h3 class="check-total-fare">Car Details</h3>
                    <div class="col-sm-5 col-xs-12 padding-left-o">
                        <div class="get-car-details-area clearfix">
                            <div class="col-sm-6 padding-left-o">
                                <span class="ride-label">Car Type <span class="right-into">:</span></span>
                            </div>
                            <div class="col-sm-6">
                                <span class="ride-label-badge"><?php echo e($data->vd->car_type); ?></span>
                            </div>
                        </div>
                        <div class="get-car-details-area clearfix">
                            <div class="col-sm-6 padding-left-o">
                                <span class="ride-label">Car Plate No <span class="right-into">:</span></span>
                            </div>
                            <div class="col-sm-6">
                                <span class="ride-label-badge"><?php echo e($data->vd->car_plate_no); ?></span>
                            </div>
                        </div>
                        <div class="get-car-details-area clearfix">
                            <div class="col-sm-6 padding-left-o">
                                <span class="ride-label">Maximum Luggage <span class="right-into">:</span></span>
                            </div>
                            <div class="col-sm-6">
                                <span class="ride-label-badge"><?php echo e($data->vd->luggage_limit); ?></span>
                            </div>
                        </div>
                        <div class="get-car-details-area clearfix">
                            <div class="col-sm-6 padding-left-o">
                                <span class="ride-label">Language<span class="right-into">:</span></span>
                            </div>
                            <div class="col-sm-6">
                                <span class="ride-label-badge"><?php echo e($data->vd->language); ?></span>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-3 col-sm-offset-3 col-xs-12 ride-details-feature">
                        <ul class="get-ride-feature">
                            <li>
                                <span class="right-ride-feature <?php $__currentLoopData = $data->rd; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if($r->key == 'pets'): ?><?php if( $r->value == 'yes'): ?><?php echo e("icon-feature-details"); ?><?php else: ?><?php echo e("icon-cross-details"); ?><?php endif; ?> <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>"></span>
                                <span class="left-ride-feature">Pets</span>
                            </li>
                            <li>
                                <span class="right-ride-feature <?php $__currentLoopData = $data->rd; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if($r->key == 'music'): ?><?php if( $r->value == 'yes'): ?><?php echo e("icon-feature-details"); ?><?php else: ?><?php echo e("icon-cross-details"); ?><?php endif; ?> <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>"></span>
                                <span class="left-ride-feature">Music</span>
                            </li>
                            <li>
                                <span class="right-ride-feature <?php $__currentLoopData = $data->rd; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if($r->key == 'smoking'): ?><?php if( $r->value == 'yes'): ?><?php echo e("icon-feature-details"); ?><?php else: ?><?php echo e("icon-cross-details"); ?><?php endif; ?> <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>"></span>
                                <span class="left-ride-feature">Smoking</span>
                            </li>
                            <li>
                                <span class="right-ride-feature <?php $__currentLoopData = $data->rd; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if($r->key == 'back_seat'): ?><?php if( $r->value == 'yes'): ?><?php echo e("icon-feature-details"); ?><?php else: ?><?php echo e("icon-cross-details"); ?><?php endif; ?> <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>"></span>
                                <span class="left-ride-feature">Max.2 in back Seat</span>
                            </li>
                            <?php $__currentLoopData = $data->rd; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(!in_array($r->key, ['vehicle_id', 'pets', 'music', 'smoking', 'back_seat'])): ?>
                                    <li>
                                        <span class="right-ride-feature <?php if( $r->value == 'yes'): ?><?php echo e("icon-feature-details"); ?><?php else: ?><?php echo e("icon-cross-details"); ?><?php endif; ?>"></span>
                                        <span class="left-ride-feature"><?php echo e($r->key); ?></span>
                                    </li>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                    <?php if(Auth::id() != $data->offer_by): ?>
                    <button class="btn btn-info btn-offer ride-final-ride-button" type="button" data-toggle="modal" data-target="#myModalx">Ridemate Details</button>
                        <?php endif; ?>
                    <?php if(Auth::check() && Auth::user()->role == 'driver' && !isset($ride_start->start_time) && Auth::id() == $data->offer_by): ?>
                        <button class="btn btn-info btn-offer ride-final-ride-button" type="button"><a style="color: #ffffff" href="<?php echo e(url('/d/edit-ride/'.$data->link)); ?>">Edit Ride Details</a></button>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <!-- end offer a ride -->
    <?php $__env->stopSection(); ?>


<?php echo $__env->make('frontend.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>