<?php $__env->startSection('content'); ?>

    <!--ridemate profile -->
    <div class="get-offer-ride  get-ride-mate-profile">
        <div class="container">
            <div class="row">
                <div class="price-seat">

                    <div class="my-bookings-area clearfix">
                        <h3 class="get-popular-list">My Bookings</h3>
                        <div class="col-sm-12 clearfix">
                            <?php echo $__env->make('frontend.includes.messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                            <?php if(isset($errors)): ?>
                                <?php $__currentLoopData = $errors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <p class="alert alert-danger">
                                        <?php echo e($error); ?>

                                    </p>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($book->ride_details->status == 'active'): ?>
                        <!-- single ride area -->
                        <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12 padding-left-o">
                            <div class="single-booking-point">
                                <div class="col-sm-5 padding-left-o">
                                    <div class="departure-to-arrival clearfix">
                                        <div class="arrival-line">
                                            <span class="my-location"></span>
                                            <span class="arrival-lin-get"></span>
                                            <span><i class="fas fa-map-marker-alt"></i></span>
                                        </div>
                                        <div class="get-area-details">
                                            <div class="get-ride-departure-time">
                                                <h3 class="departure-ride"><?php echo e($book->ride_details->origin); ?></h3>
                                                <h4 class="depature-time-get">Departure time: <span><?php echo e($book->ride_details->departure_time); ?></span></h4>
                                            </div>
                                            <div class="get-ride-departure-time">
                                                <h3 class="departure-ride"><?php echo e($book->ride_details->destination); ?></h3>
                                                <h4 class="depature-time-get">Arrival time: <span><?php echo e($book->ride_details->arrival_time); ?></span></h4>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="ridemade-details-button">
                                        <button class="btn btn-info btn-offer" data-toggle="modal" data-target="#myModalRD<?php echo e($book->id); ?>">Ridemates Details</button>
                                    </div>
                                </div>
                                <div class="col-sm-2">
                                    <div class="total-fare-area">
                                        <h3 class="total-fare-get-section">
                                            Total Fare <span>$<?php echo e($book->ride_details->price_per_seat); ?></span>
                                        </h3>
                                        <h3 class="total-fare-get-section">
                                            Status : <span><?php if($book->status == 'booked'): ?> <i class="fa fa-exclamation-circle"></i> <?php elseif($book->status == 'confirmed'): ?> <i class="fa fa-check-circle"></i> <?php else: ?> <?php echo e('None'); ?> <?php endif; ?></span>
                                        </h3>
                                        <a href="<?php echo e(url('/c/ride-details/'.$book->ride_details->link)); ?>"><button class="btn btn-info btn-offer"><i class="fas fa-location-arrow"></i> <br> View <br> Details</button></a>
                                    </div>
                                </div>
                                <div class="col-sm-5">
                                    <div class="car-details-type-arrow">
                                        <h3>Car Details</h3>
                                        <ul>
                                            <li><span class="ride-label">Car Type <span class="right-into">: <?php echo e($book->vd->car_type); ?></span></span>
                                            </li>
                                            <li>
                                                <span class="ride-label">Car Plate No <span class="right-into">: <?php echo e($book->vd->car_plate_no); ?></span></span>
                                            </li>
                                            <li>
                                                <span class="ride-label">Maximum Luggage <span class="right-into">: <?php echo e($book->vd->luggage_limit); ?></span></span>
                                            </li>
                                        </ul>
                                        <button class="btn btn-info btn-offer" type="button" data-toggle="modal" data-target="#myModalCancel<?php echo e($book->id); ?>">Cancel Booking</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <!-- end ridemate profile area  -->

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>