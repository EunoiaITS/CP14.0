<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="col-sm-8">
            <div class="forget-password-ex">
                <?php if(session('status')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(session('status')); ?>

                    </div>
                <?php endif; ?>
                    <form method="POST" action="<?php echo e(route('password.email')); ?>">
                        <?php echo csrf_field(); ?>
                    <h2 class="highlight">Forget Password</h2>
                    <p>Simply Enter Your Email to Reset Your Password.</p>
                    <div class="form-group">
                        <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required>
                        <?php if($errors->has('email')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('email')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                    <div class="sign-in-option-get clearfix">
                        <button type="submit" class="btn btn-info btn-offer">Submit</button>
                        <a class="btn btn-info btn-offer btn-cancel" href="#">Cancel</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>