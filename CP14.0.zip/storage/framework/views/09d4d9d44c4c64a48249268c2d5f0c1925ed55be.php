<script type="text/javascript"
        src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDSDYEWgbPh1YBGNEZoMye44-F9ugukmRo&libraries=places">
</script>

<script src="<?php echo e(asset('public/assets/frontend/js/jquery.placepicker.js')); ?>"></script>

<script>

    $(document).ready(function() {

        // Basic usage
        $(".placepicker").placepicker();

    }); // END document.ready

</script>