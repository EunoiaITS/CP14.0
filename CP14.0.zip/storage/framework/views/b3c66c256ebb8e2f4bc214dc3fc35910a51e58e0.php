<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="col-sm-8">
            <div class="forget-password-ex">
                <form method="POST" action="<?php echo e(route('password.request')); ?>">
                    <?php echo csrf_field(); ?>

                    <input type="hidden" name="token" value="<?php echo e($token); ?>">
                    <h2 class="highlight new-hightlight">Reset Password</h2>
                    <div class="form-group">
                        <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e($email ?? old('email')); ?>" placeholder="Enter Your Email Address" required autofocus>

                        <?php if($errors->has('email')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('email')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" placeholder="Enter Your Password" required>

                        <?php if($errors->has('password')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('password')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <input id="password-confirm" type="password" class="form-control" name="password_confirmation" placeholder="Re-Type Your Password" required>
                    </div>
                    <div class="sign-in-option-get clearfix">
                        <button type="submit" class="btn btn-info btn-offer">Submit</button>
                        <a class="btn btn-info btn-offer btn-cancel" href="#">Cancel</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>