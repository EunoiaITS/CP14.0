<?php $__env->startSection('content'); ?>
    <!-- sign in page -->
    <div class="get-offer-ride">
        <div class="container">
            <div class="row">
                <?php if(session()->has('error')): ?>
                    <div class="alert alert-danger">
                        <?php echo e(session()->get('error')); ?>

                    </div>
                <?php endif; ?>
                    <?php if(session()->has('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session()->get('success')); ?>

                        </div>
                    <?php endif; ?>
                <div class="col-sm-12 sign-in-get-ad padding-left-o padding-right-o">
                    <h3 class="get-popular-list">Welcome</h3>
                    <h3 class="highlight">Back!</h3>
                </div>
                <!-- search result page -->
                <div class="col-sm-8 col-xs-12">
                    <form method="post" action="<?php echo e(route('login')); ?>">
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group">
                            <input type="email" id="email" name="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" placeholder="Email Address" value="<?php echo e(old('email')); ?>" required autofocus>
                            <?php if($errors->has('email')): ?>
                            <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('email')); ?></strong>
                            </span>
                            <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <input id="password" placeholder="Password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required>
                        <?php if($errors->has('password')): ?>
                        <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('password')); ?></strong>
                        </span>
                        <?php endif; ?>
                    </div>
                    <ul class="remember-me clearfix">
                        <li>
                            <div class="remember-me-option">
                                <input type="checkbox" id="checkbox1" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                                <label for="checkbox1">Remember Me</label>
                            </div>
                        </li>
                        <li>
                            <div class="forget-pass-get"><a href="<?php echo e(route('password.request')); ?>">Forget Password</a></div>
                        </li>
                    </ul>
                    <div class="sign-in-option-get">
                        <button class="btn btn-info btn-offer" type="submit" >Sign In</button>
                        <span>Or</span>
                        <button class="btn btn-info btn-offer join-us-sign-in" type="button">Join Us</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>