<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($book->ride_details->status == 'active'): ?>

        <!-- cancel booking popup -->
        <div class="modal fade" id="myModalCancel<?php echo e($book->id); ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        <h4 class="modal-title" id="myModalLabel">Cancel Booking</h4>
                    </div>
                    <div class="modal-body table-responsive">
                        <p>Are you sure you want to cancel your booking ?</p>
                    </div>
                    <div class="modal-footer login-modal-footer">
                        <form method="post" id="cancel-book" action="<?php echo e(url('/c/cancel-book')); ?>">
                            <?php echo e(csrf_field()); ?>

                            <input type="hidden" name="book_id" value="<?php echo e($book->id); ?>">
                            <input type="hidden" name="page_url" value="<?php echo e(url()->current()); ?>">
                        </form>
                        <button type="submit" form="cancel-book" class="btn btn-info btn-offer">Confirm</button>
                        <button class="btn btn-info btn-offer" data-dismiss="modal" aria-label="Close">Cancel</button>
                    </div>
                </div>
            </div>
        </div>
        <!-- end cancel booking popup -->

    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($book->ride_details->status == 'active'): ?>

        <!-- cancel booking popup -->
        <div class="modal fade" id="myModalCancel<?php echo e($book->id); ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        <h4 class="modal-title" id="myModalLabel">Cancel Booking</h4>
                    </div>
                    <div class="modal-body table-responsive">
                        <p>Are you sure you want to cancel your booking ?</p>
                    </div>
                    <div class="modal-footer login-modal-footer">
                        <form method="post" id="cancel-book" action="<?php echo e(url('/c/cancel-book')); ?>">
                            <?php echo e(csrf_field()); ?>

                            <input type="hidden" name="book_id" value="<?php echo e($book->id); ?>">
                            <input type="hidden" name="page_url" value="<?php echo e(url()->current()); ?>">
                        </form>
                        <button type="submit" form="cancel-book" class="btn btn-info btn-offer">Confirm</button>
                        <button class="btn btn-info btn-offer" data-dismiss="modal" aria-label="Close">Cancel</button>
                    </div>
                </div>
            </div>
        </div>
        <!-- end cancel booking popup -->

        <!--Riders details -->
        <div class="modal fade" id="myModalRD<?php echo e($book->id); ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        <h4 class="modal-title" id="myModalLabel">Ridemate Details</h4>
                    </div>
                    <div class="modal-body rider-details-ridemate">
                        <h3 class="rider-title">Ridemate</h3>
                        <div class="ridemate-name-area">
                            <div class="ridemate-name">
                                Name <span class="ridemate-right">:</span>
                            </div>
                            <div class="ridemate-name-xs">
                                <span><?php echo e($book->user->name); ?></span>
                            </div>
                        </div>
                        <div class="ridemate-name-area">
                            <div class="ridemate-name">
                                Email <span class="ridemate-right">:</span>
                            </div>
                            <div class="ridemate-name-xs">
                                <span><?php echo e($book->user->email); ?></span>
                            </div>
                        </div>

                        <div class="ridemate-name-area">
                            <div class="ridemate-name">
                                Gender <span class="ridemate-right">:</span>
                            </div>
                            <div class="ridemate-name-xs">
                                <span><?php echo e($book->ud->gender); ?></span>
                            </div>
                        </div>
                        <div class="ridemate-name-area">
                            <div class="ridemate-name">
                                Age <span class="ridemate-right">:</span>
                            </div>
                            <div class="ridemate-name-xs">
                                <span><?php echo e(date('Y') - date('Y',strtotime($book->ud->dob))); ?></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>