<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class RideRequestTemp extends Model
{
    protected $table = 'ride_request_temp';
}
