@include('frontend.includes.head')
@include('frontend.includes.admin-header')
@yield('content')
@include('frontend.includes.footer')