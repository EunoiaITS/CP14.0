<body>

<div class="wrapper">
    <!-- header area -->
    <div class="get-header">
        <div class="navbar nav">
            <div class="container">
                <div class="col-sm-7 col-xs-10">
                    <div class="get-logo text-center">
                        <a href="{{ url('/') }}"><h2 class="get-logo-text"><span>Get</span>Wobo </h2></a>
                        <h2>Admin Panel</h2>
                    </div>
                </div>
            </div>
            <hr>
        </div>

    </div>
    <!-- end header area -->
</div>
<!-- end header area -->