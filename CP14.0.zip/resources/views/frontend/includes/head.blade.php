<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>GetWobo</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- stylesheet css -->
    <link rel="stylesheet" href="{{ asset('public/assets/frontend/css/fontawesome-all.min.css') }}">
    <!-- bootstrap css -->
    <link rel="stylesheet" href="{{ asset('public/assets/frontend/css/bootstrap.min.css') }}">
    <!-- bootstrap select -->
    <link rel="stylesheet" href="{{ asset('public/assets/frontend/css/bootstrap-select.css') }}">
    <!-- datepicker css -->
    <link rel="stylesheet" href="{{ asset('public/assets/frontend/css/bootstrap-datetimepicker.css') }}">
    <!-- weekly datepicker css -->
    <link rel="stylesheet" href="{{ asset('public/assets/frontend/css/jquery-ui-1.10.4.smoothness.css') }}">
    <!-- style css -->
    <link rel="stylesheet" href="{{ asset('public/assets/frontend/css/style.css') }}">
    <!-- mordernizr css -->
    <script src="{{ asset('public/assets/frontend/js/vendor/modernizr.custom.97074.js') }}"></script>
</head>
